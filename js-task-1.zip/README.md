# calculator in Javascript
First Task || Javascript || Calculator
